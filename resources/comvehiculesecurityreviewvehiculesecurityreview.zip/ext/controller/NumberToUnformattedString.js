sap.ui.define([],function(){"use strict";return{keepOnlyNumericCharacters:function(e){return e.replace(/\D/g,"")}}});
//# sourceMappingURL=NumberToUnformattedString.js.map