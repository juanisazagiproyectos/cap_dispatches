sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.cargoordermanagement.cargoordermanagement.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);